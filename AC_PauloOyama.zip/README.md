"# FireSpread" 

To run this project, run ```dotnet run``` on your cmd